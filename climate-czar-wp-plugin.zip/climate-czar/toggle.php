<?php
//---------------------------------------------------------------------------------------------------
require_once("../../../wp-config.php");
require_once("functions.php");
//---------------------------------------------------------------------------------------------------
// Cheap but very effective trick to protect process.php from nefarious curl posts
// Just try to avoid opening a form before midnight and submitting it after midnight
if (isset($_COOKIE["PrOcEsS012023"])) {
  $D = date('w');
  if (($D == 0) && ($_COOKIE["PrOcEsS012023"] != AUTH_KEY)) exit;
  if (($D == 1) && ($_COOKIE["PrOcEsS012023"] != SECURE_AUTH_KEY)) exit;
  if (($D == 2) && ($_COOKIE["PrOcEsS012023"] != NONCE_KEY)) exit;
  if (($D == 3) && ($_COOKIE["PrOcEsS012023"] != AUTH_SALT)) exit;
  if (($D == 4) && ($_COOKIE["PrOcEsS012023"] != SECURE_AUTH_SALT)) exit;
  if (($D == 5) && ($_COOKIE["PrOcEsS012023"] != LOGGED_IN_SALT)) exit;
  if (($D == 6) && ($_COOKIE["PrOcEsS012023"] != NONCE_SALT)) exit;
} else {
  exit;
}
//---------------------------------------------------------------------------------------------------
if ($_GET["Type"] == 0) {
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Query = "";
  if ($_GET["Mode"] == 1) $Query = ",Manual=1";
  if ($_GET["Mode"] == 2) $Query = ",Manual=2";
  $Result = mysqli_query($DBcnx,"UPDATE OutputSwitches SET OpMode=" . $_GET["Mode"] . "$Query WHERE ID=" . $_GET["ID"]);
  mysqli_close($DBcnx);
} else {
  $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Result = mysqli_query($DBcnx,"UPDATE InputDevices SET Reading=" . $_GET["Mode"] . " WHERE ID=" . $_GET["ID"]);
  $Result = mysqli_query($DBcnx,"INSERT INTO InputHistory (DeviceID,TimeStamp,Reading,RawText) VALUES (" . $_GET["ID"] . ",now(),'" . $_GET["Mode"] . "','')");
  mysqli_close($DBcnx);
}
if ($_GET["Basic"] == 1) {
//echo($_SERVER["HTTP_REFERER"]);
  header("Location: " . $_SERVER["HTTP_REFERER"]);
} else {
  echo("<p class=\"text-primary-emphasis\" style=\"font-style: italic;font-size: 0.9em;\">Processing...</p>\n");
}
//---------------------------------------------------------------------------------------------------
?>
