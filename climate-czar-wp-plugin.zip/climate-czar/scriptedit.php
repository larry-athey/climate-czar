<?php
//---------------------------------------------------------------------------------------------------
require_once("../../../wp-config.php");
require_once("functions.php");
//---------------------------------------------------------------------------------------------------
// Cheap but very effective trick to protect process.php from nefarious curl posts
// Just try to avoid opening a form before midnight and submitting it after midnight
if (isset($_COOKIE["PrOcEsS012023"])) {
  $D = date('w');
  if (($D == 0) && ($_COOKIE["PrOcEsS012023"] != AUTH_KEY)) exit;
  if (($D == 1) && ($_COOKIE["PrOcEsS012023"] != SECURE_AUTH_KEY)) exit;
  if (($D == 2) && ($_COOKIE["PrOcEsS012023"] != NONCE_KEY)) exit;
  if (($D == 3) && ($_COOKIE["PrOcEsS012023"] != AUTH_SALT)) exit;
  if (($D == 4) && ($_COOKIE["PrOcEsS012023"] != SECURE_AUTH_SALT)) exit;
  if (($D == 5) && ($_COOKIE["PrOcEsS012023"] != LOGGED_IN_SALT)) exit;
  if (($D == 6) && ($_COOKIE["PrOcEsS012023"] != NONCE_SALT)) exit;
} else {
  exit;
}
//---------------------------------------------------------------------------------------------------
if (! $_GET) {
  exit;
} else {
  if (! isset($_GET["LOGGED_IN_KEY"])) {
    exit;
  } else {
    if ($_GET["LOGGED_IN_KEY"] != LOGGED_IN_KEY) exit;
  }
  if (isset($_GET["ScriptName"])) {
    $ScriptName = $_GET["ScriptName"];
    $OldName    = $ScriptName;
    if ($ScriptName == "new-script") {
      $Code = "#!/bin/bash\\n\\n";
    } else {
      $Code = file_get_contents("../../../commands/$ScriptName");
      $Code = addslashes($Code);
      $Code = str_replace("\n","\\n",$Code);
    }
  } else {
    $ScriptName = "new-script";
    $OldName    = $ScriptName;
    $Code       = "#!/bin/bash\\n\\n";
  }
}
//---------------------------------------------------------------------------------------------------
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Script Editor</title>
  <meta http-equiv="cache-control" content="max-age=0">
  <meta http-equiv="cache-control" content="no-cache">
  <meta http-equiv="expires" content="0">
  <meta http-equiv="expires" content="Thu, 01 Jan 1970 1:00:00 GMT">
  <meta http-equiv="pragma" content="no-cache">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
  <form id="scripteditor" method="post" action="process.php" target="_top" onSubmit="setupFormPost()">
  <table class="table table-borderless">
    <tr>
      <td colspan="3"><div id="vscode" style="width:100%;height:700px;border:1px solid grey;"></div></td>
    <tr>
    <tr>
      <td width="33%" align="left">
        <a class="btn btn-success" href="scriptedit.php?LOGGED_IN_KEY=<?= urlencode(LOGGED_IN_KEY) ?>&RETURN_PAGE=<?= urlencode($_GET["RETURN_PAGE"]) ?>&ScriptName=new-script" role="button">New Script</a>
      </td>
      <td width="33%" align="right">
        <input type="submit" class="btn btn-primary" name="cz_script_edit_save" value="Save Script">
      </td>
      <td  width="33%">
        <input class="form-control" name="ScriptName" type="text" maxlength="50" value="<?= $ScriptName ?>">
        <input type="hidden" id="Code" name="Code" value="">
        <input type="hidden" name="OldName" value="<?= $OldName ?>">
        <input type="hidden" name="LOGGED_IN_KEY" value="<?= LOGGED_IN_KEY ?>">
        <input type="hidden" name="RETURN_PAGE" value="<?= $_GET["RETURN_PAGE"] ?>">
      </td>
    </tr>
  </table>
  </form>

  <script src="../../../monaco-editor/min/vs/loader.js"></script>
  <script type="text/javascript">
    require.config({ paths: { 'vs': '../../../monaco-editor/min/vs' }});
    require(['vs/editor/editor.main'], function() {
      var editor = monaco.editor.create(document.getElementById('vscode'), {
        value: '<?= $Code ?>',
<?php if (InStr(".php",$ScriptName)) { ?>
        language: 'php',
<?php } elseif (InStr(".py",$ScriptName)) { ?>
        language: 'python',
<?php } else { ?>
        language: 'shell',
<?php } ?>
        theme: 'vs-dark'
      });
    });

    function setupFormPost() {
      var value = monaco.editor.getModels()[0].getValue();
      jQuery('#Code').val(value);
      return true;
    }
  </script>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>
</html>
