<?php
//---------------------------------------------------------------------------------------------------
require_once("../../../wp-config.php");
require_once("functions.php");
//---------------------------------------------------------------------------------------------------
// Cheap but very effective trick to protect process.php from nefarious curl posts
// Just try to avoid opening a form before midnight and submitting it after midnight
if (isset($_COOKIE["PrOcEsS012023"])) {
  $D = date('w');
  if (($D == 0) && ($_COOKIE["PrOcEsS012023"] != AUTH_KEY)) exit;
  if (($D == 1) && ($_COOKIE["PrOcEsS012023"] != SECURE_AUTH_KEY)) exit;
  if (($D == 2) && ($_COOKIE["PrOcEsS012023"] != NONCE_KEY)) exit;
  if (($D == 3) && ($_COOKIE["PrOcEsS012023"] != AUTH_SALT)) exit;
  if (($D == 4) && ($_COOKIE["PrOcEsS012023"] != SECURE_AUTH_SALT)) exit;
  if (($D == 5) && ($_COOKIE["PrOcEsS012023"] != LOGGED_IN_SALT)) exit;
  if (($D == 6) && ($_COOKIE["PrOcEsS012023"] != NONCE_SALT)) exit;
} else {
  exit;
}
//---------------------------------------------------------------------------------------------------
if (! $_GET) {
  exit;
} else {
  if (! isset($_GET["LOGGED_IN_KEY"])) {
    exit;
  } else {
    if ($_GET["LOGGED_IN_KEY"] != LOGGED_IN_KEY) exit;
  }
  if (isset($_GET["FormID"])) {
    $FormID = $_GET["FormID"];
  } else {
    $FormID = 0;
  }
}
//---------------------------------------------------------------------------------------------------
function RGBtoHEX($Value) {
  $RGB = explode(",",$Value);
  $RGB[0] = dechex($RGB[0]);
  if (strlen($RGB[0]) < 2) $RGB[0] = '0' . $RGB[0];
  $RGB[1] = dechex($RGB[1]);
  if (strlen($RGB[1]) < 2) $RGB[1] = '0' . $RGB[1];
  $RGB[2] = dechex($RGB[2]);
  if (strlen($RGB[2]) < 2) $RGB[2] = '0' . $RGB[2];
  return '#' . $RGB[0] . $RGB[1] . $RGB[2];
}
//---------------------------------------------------------------------------------------------------
if ($FormID == 1) { // Group Editor
  if (! isset($_GET["GroupID"])) {
    echo("No GroupID Provided");
    exit;
  }
  if ($_GET["GroupID"] > 0) {
    $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
    $Result = mysqli_query($DBcnx,"SELECT * FROM DeviceGroups WHERE ID=" . $_GET["GroupID"]);
    if (mysqli_num_rows($Result) > 0) {
      $Group = mysqli_fetch_assoc($Result);
    } else {
      mysqli_close($DBcnx);
      echo("GroupID Not Found");
      exit;
    }
    mysqli_close($DBcnx);
  } else {
    $Group["Name"] = "";
  }
} elseif ($FormID == 2) { // Input Sensor Editor
  if ($_GET["DeviceID"] > 0) {
    $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
    $Result = mysqli_query($DBcnx,"SELECT * FROM InputDevices WHERE ID=" . $_GET["DeviceID"]);
    if (mysqli_num_rows($Result) > 0) {
      $Dev = mysqli_fetch_assoc($Result);
      $Dev["DeviceName"]    = htmlspecialchars($Dev["DeviceName"],ENT_QUOTES);
      $Dev["ReadingSuffix"] = htmlspecialchars($Dev["ReadingSuffix"],ENT_QUOTES);
      $Dev["GraphColor"]    = RGBtoHEX($Dev["GraphColor"]);
      $Dev["ScheduleList"]  = htmlspecialchars($Dev["ScheduleList"],ENT_QUOTES);
      $Dev["Notes"]         = htmlspecialchars($Dev["Notes"],ENT_QUOTES);
    } else {
      mysqli_close($DBcnx);
      echo("DeviceID Not Found");
      exit;
    }
    mysqli_close($DBcnx);
  } else {
    $Dev["DeviceName"]    = "";
    $Dev["DeviceType"]    = "1";
    $Dev["Dashboard"]     = "1";
    $Dev["Position"]      = "1";
    $Dev["SwitchSec"]     = "subscriber";
    $Dev["GroupID"]       = $_COOKIE["CZ_GROUP"];
    $Dev["ReadingSuffix"] = "";
    $Dev["GraphColor"]    = "#9966FF";
    $Dev["BGlow"]         = "30";
    $Dev["BGmid"]         = "60";
    $Dev["BGhigh"]        = "90";
    $Dev["SensorList"]    = "";
    $Dev["SwitchList"]    = "";
    $Dev["ScheduleList"]  = "";
    $Dev["ReadCommand"]   = "/var/www/html/climateczar/commands/your-script";
    $Dev["Notes"]         = "";
  }
} elseif ($FormID == 3) { // Output Switch Editor
  if ($_GET["DeviceID"] > 0) {
    $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
    $Result = mysqli_query($DBcnx,"SELECT * FROM OutputSwitches WHERE ID=" . $_GET["DeviceID"]);
    if (mysqli_num_rows($Result) > 0) {
      $Dev = mysqli_fetch_assoc($Result);
      $Dev["DeviceName"] = htmlspecialchars($Dev["DeviceName"],ENT_QUOTES);
      $Dev["GraphColor"] = RGBtoHEX($Dev["GraphColor"]);
      $Dev["Notes"]      = htmlspecialchars($Dev["Notes"],ENT_QUOTES);
    } else {
      mysqli_close($DBcnx);
      echo("DeviceID Not Found");
      exit;
    }
    mysqli_close($DBcnx);
  } else {
    $Dev["DeviceName"]     = "";
    $Dev["Dashboard"]      = "1";
    $Dev["Position"]       = "1";
    $Dev["SwitchSec"]      = "subscriber";
    $Dev["GroupID"]        = $_COOKIE["CZ_GROUP"];
    $Dev["InputID"]        = "0";
    $Dev["OverrideID"]     = "0";
    $Dev["OverrideStatus"] = "1";
    $Dev["Polarity"]       = "0";
    $Dev["LowValue"]       = "50";
    $Dev["HighValue"]      = "100";
    $Dev["OneShot"]        = "1";
    $Dev["GraphColor"]     = "#26A644";
    $Dev["OnCommand"]      = "/var/www/html/climateczar/commands/your-script &";
    $Dev["OffCommand"]     = "/var/www/html/climateczar/commands/your-script &";
    $Dev["Notes"]          = "";
  }
  $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Result = mysqli_query($DBcnx,"SELECT * FROM InputDevices WHERE GroupID=" . $_COOKIE["CZ_GROUP"] . " AND DeviceType < 9 ORDER BY DeviceName");
  if (mysqli_num_rows($Result) > 0) {
    $JSarray = "const Dev = [];\n       Dev[0] = 0;\n";
    while ($RS = mysqli_fetch_assoc($Result)) {
      $JSarray .= "       Dev[" . $RS["ID"] . "] = " . $RS["DeviceType"] . ";\n";
    }
  }
  mysqli_close($DBcnx);
}
//---------------------------------------------------------------------------------------------------
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Form Editor</title>
  <meta http-equiv="cache-control" content="max-age=0">
  <meta http-equiv="cache-control" content="no-cache">
  <meta http-equiv="expires" content="0">
  <meta http-equiv="expires" content="Thu, 01 Jan 1970 1:00:00 GMT">
  <meta http-equiv="pragma" content="no-cache">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>

<?php if ($FormID == 1) { ?>
  <div style="margin: 0.5em;">
    <form id="formedit" method="post" action="process.php" target="_top">
    <div class="mb-3">
      <label for="GroupName" class="form-label">Group Name</label>
      <input type="text" class="form-control" id="GroupName" name="GroupName" maxlength="50" value="<?= $Group["Name"] ?>" aria-describedby="GroupNameHelp">
      <div id="GroupNameHelp" class="form-text">Maximum group name length is limited to 50 characters</div>
    </div>
    <button type="submit" class="btn btn-primary btn-sm" name="cz_group_save">Submit</button>
    <input type="hidden" name="ID" value="<?= $_GET["GroupID"] ?>">
    <input type="hidden" name="LOGGED_IN_KEY" value="<?= LOGGED_IN_KEY ?>">
    <input type="hidden" name="RETURN_PAGE" value="<?= $_GET["RETURN_PAGE"] ?>">
    </form>
  </div>
<?php } elseif ($FormID == 2) { ?>
  <script type="text/javascript">
  //---------------------------------------------------------------------------------------------------
  function ToggleInputFields(DeviceType) {
    var Value = DeviceType.options[DeviceType.selectedIndex].value;
    if (Value <= 2) {
      if (Value == 2) {
        ReadCommandDiv.style.display  = 'none';
        SensorListDiv.style.display   = 'inline';
      } else {
        ReadCommandDiv.style.display  = 'inline';
        SensorListDiv.style.display   = 'none';
      }
      ReadingSuffixDiv.style.display  = 'inline';
      SwitchSecDiv.style.display      = 'none';
      VariableMeterDiv.style.display  = 'inline';
      SwitchListDiv.style.display     = 'none';
      ScheduleListDiv.style.display   = 'none';
    } else {
      ReadingSuffixDiv.style.display  = 'none';
      SensorListDiv.style.display     = 'none';
      VariableMeterDiv.style.display  = 'none';
      if ((Value == 3) || (Value == 9)) {
        ReadCommandDiv.style.display  = 'inline';
      } else {
        ReadCommandDiv.style.display  = 'none';
      }
      if ((Value >= 4) && (Value <= 6)) {
        SwitchListDiv.style.display   = 'inline';
      } else {
        SwitchListDiv.style.display   = 'none';
      }
      if (Value == 7) {
        ScheduleListDiv.style.display = 'inline';
      } else {
        ScheduleListDiv.style.display = 'none';
      }
      if (Value == 8) {
        SwitchSecDiv.style.display    = 'inline';
      } else {
        SwitchSecDiv.style.display    = 'none';
      }
      if (Value == 9) {
        GraphColorDiv.style.display   = 'none';
      } else {
        GraphColorDiv.style.display   = 'inline';
      }
    }
  }
  //---------------------------------------------------------------------------------------------------
  window.onload = function() {
    ToggleInputFields(document.getElementById('DeviceType'));
  }
  //---------------------------------------------------------------------------------------------------
  </script>

  <div style="margin: 0.5em;">
    <form id="formedit" method="post" action="process.php" target="_top">
    <div class="mb-3">
      <label for="DeviceName" class="form-label">Device Name</label>
      <input type="text" class="form-control" id="DeviceName" name="DeviceName" maxlength="50" value="<?= $Dev["DeviceName"] ?>" aria-describedby="DeviceNameHelp">
      <div id="DeviceNameHelp" class="form-text">Maximum device name length is limited to 50 characters</div>
    </div>
    <div style="margin-bottom: 1em;">
      <label for="DeviceType" class="form-label">Device Type</label>
      <?= DeviceTypeSelector($Dev["DeviceType"]) ?>
    </div>
    <div class="mb-3" id="ReadCommandDiv">
      <label for="ReadCommand" class="form-label">Device Read Command</label>
      <input type="text" class="form-control" id="ReadCommand" name="ReadCommand" maxlength="255" value="<?= $Dev["ReadCommand"] ?>" aria-describedby="ReadCommandHelp">
      <div id="ReadCommandHelp" class="form-text">Full path and file name of the script or executable and optional parameters</div>
    </div>
    <div style="margin-top: 1em;">
      <label for="Dashboard" class="form-label">Show in Dashboard?</label>
      <?= YNSelector($Dev["Dashboard"],"Dashboard") ?>
    </div>
    <div class="mb-3">
      <label for="Position" class="form-label">Dashboard Position</label>
      <input type="number" min="1" max="99" class="form-control" id="Position" name="Position" value="<?= $Dev["Position"] ?>" aria-describedby="PositionHelp">
      <div id="PositionHelp" class="form-text">This device's position as input sensors are displayed from left to right in the dashboard</div>
    </div>
    <div>
      <label for="GroupID" class="form-label">Device Group Assignment</label>
      <?= GroupSelector($Dev["GroupID"]) ?>
    </div>
    <div class="mb-3" style="margin-top: 1em;" id="GraphColorDiv">
      <label for="GraphColor" class="form-label">Graph Color</label>
      <input type="color" class="form-control" id="GraphColor" name="GraphColor" value="<?= $Dev["GraphColor"] ?>" aria-describedby="GraphColorHelp">
      <div id="GraphColorHelp" class="form-text">The color to render this device's historical graph with under Logs &amp; Graphs</div>
    </div>
    <div class="mb-3" id="ReadingSuffixDiv">
      <label for="ReadingSuffix" class="form-label">Reading Suffix</label>
      <input type="text" class="form-control" id="ReadingSuffix" name="ReadingSuffix" maxlength="50" value="<?= $Dev["ReadingSuffix"] ?>" aria-describedby="ReadingSuffixHelp">
      <div id="ReadingSuffixHelp" class="form-text" style="margin-bottom: 1em;">Suffix to display after the reading of Variable Value Sensors <i>(such as HTML character codes)</i></div>
    </div>
    <div id="SwitchSecDiv">
      <label for="SwitchSec" class="form-label">Web Console Switch Minimum Security Level</label>
      <?= SwitchSecSelector($Dev["SwitchSec"]) ?>
    </div>
    <div id="VariableMeterDiv">
      <div class="row" style="width:99%;">
        <label for="BGlow" class="form-label">Variable Value Sensor Dashboard Meter Crossover Points (1..100)</label>
        <div class="col"><input type="number" class="form-control" min="1" max="100" id="BGlow" name="BGlow" value="<?= $Dev["BGlow"]  ?>"></div>
        <div class="col"><input type="number" class="form-control" min="1" max="100" id="BGmid" name="BGmid" value="<?= $Dev["BGmid"]  ?>"></div>
        <div class="col"><input type="number" class="form-control" min="1" max="100" id="BGhigh" name="BGhigh" value="<?= $Dev["BGhigh"]  ?>"></div>
      </div>
      <div class="row" style="width:99%; margin-bottom: 0.5em;">
        <div class="col text-muted">Blue&rarr;Green</div>
        <div class="col text-muted">Green&rarr;Amber</div>
        <div class="col text-muted">Amber&rarr;Red</div>
      </div>
    </div>
    <div class="mb-3" id="SensorListDiv">
      <label for="SensorList" class="form-label">Average of multiple Variable Value Sensors</label>
      <?= ArraySelector(1,"SensorList",$Dev["SensorList"]) ?>
      <div id="SensorListHelp" class="form-text">Control/Command+Click all sensors to include in the array</div>
    </div>
    <div class="mb-3" id="SwitchListDiv">
      <label for="SwitchList" class="form-label">Logic Gate of multiple Remote Binary Switches</label>
      <?= ArraySelector(3,"SwitchList",$Dev["SwitchList"]) ?>
      <div id="SwitchListHelp" class="form-text">Control/Command+Click all switches to include in the array</div>
    </div>
    <div class="mb-3" id="ScheduleListDiv">
      <label for="ScheduleList" class="form-label">Daily Schedule List</label>
      <textarea class="form-control" id="ScheduleList" name="ScheduleList" style="height: 100px;" aria-describedby="ScheduleListHelp"><?= $Dev["ScheduleList"] ?></textarea>
      <div id="ScheduleListHelp" class="form-text">ON/OFF schedules in 24 hour format on separate lines (example: 06:00-21:00)</div>
    </div>
    <div style="margin-top: 1em; margin-bottom: 1em;">
      <label for="Notes" class="form-label">Device Notes</label>
      <textarea class="form-control" id="Notes" name="Notes" style="height: 100px;"><?= $Dev["Notes"] ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary" name="cz_input_sensor_save">Submit</button>
    <input type="hidden" name="ID" value="<?= $_GET["DeviceID"] ?>">
    <input type="hidden" name="LOGGED_IN_KEY" value="<?= LOGGED_IN_KEY ?>">
    <input type="hidden" name="RETURN_PAGE" value="<?= $_GET["RETURN_PAGE"] . "?DevType=0" ?>">
    </form>
  </div>
<?php } elseif ($FormID == 3) { ?>
  <script type="text/javascript">
  //---------------------------------------------------------------------------------------------------
  function ToggleOutputFields(DeviceType) {
    var Value = DeviceType.options[DeviceType.selectedIndex].value;
    // Insert the PHP generated InputType array here
    <?= $JSarray ?>
    InputType = Dev[Value];
    if ((InputType == 1) || (InputType == 2)) {
      HighLowDiv.style.display  = 'inline';
      PolarityDiv.style.display = 'inline';
    } else {
      HighLowDiv.style.display  = 'none';
      PolarityDiv.style.display = 'none';
    }
  }
  //---------------------------------------------------------------------------------------------------
  window.onload = function() {
    ToggleOutputFields(document.getElementById('InputID'));
  }
  //---------------------------------------------------------------------------------------------------
  </script>

  <div style="margin: 0.5em;">
    <form id="formedit" method="post" action="process.php" target="_top">
    <div class="mb-3">
      <label for="DeviceName" class="form-label">Device Name</label>
      <input type="text" class="form-control" id="DeviceName" name="DeviceName" maxlength="50" value="<?= $Dev["DeviceName"] ?>" aria-describedby="DeviceNameHelp">
      <div id="DeviceNameHelp" class="form-text">Maximum device name length is limited to 50 characters</div>
    </div>
    <div style="margin-bottom: 1em;">
      <label for="InputID" class="form-label">Assigned Input Sensor</label>
      <?= InputSelector($Dev["InputID"],"InputID") ?>
    </div>
    <div class="mb-3">
      <label for="OnCommand" class="form-label">Device On Command</label>
      <input type="text" class="form-control" id="OnCommand" name="OnCommand" maxlength="255" value="<?= $Dev["OnCommand"] ?>" aria-describedby="OnCommandHelp">
      <div id="OnCommandHelp" class="form-text">Full path and file name of the script or executable and optional parameters</div>
    </div>
    <div class="mb-3">
      <label for="OffCommand" class="form-label">Device Off Command</label>
      <input type="text" class="form-control" id="OffCommand" name="OffCommand" maxlength="255" value="<?= $Dev["OffCommand"] ?>" aria-describedby="OffCommandHelp">
      <div id="OffCommandHelp" class="form-text">Full path and file name of the script or executable and optional parameters</div>
    </div>
    <div>
      <label for="Dashboard" class="form-label">Show in Dashboard?</label>
      <?= YNSelector($Dev["Dashboard"],"Dashboard") ?>
    </div>
    <div class="mb-3">
      <label for="Position" class="form-label">Dashboard Position</label>
      <input type="number" min="1" max="99" class="form-control" id="Position" name="Position" value="<?= $Dev["Position"] ?>" aria-describedby="PositionHelp">
      <div id="PositionHelp" class="form-text">This device's position as output switches are displayed from left to right in the dashboard</div>
    </div>
    <div style="margin-bottom: 1em;">
      <label for="GroupID" class="form-label">Device Group Assignment</label>
      <?= GroupSelector($Dev["GroupID"]) ?>
    </div>
    <div class="mb-3">
      <label for="GraphColor" class="form-label">Graph Color</label>
      <input type="color" class="form-control" id="GraphColor" name="GraphColor" value="<?= $Dev["GraphColor"] ?>" aria-describedby="GraphColorHelp">
      <div id="GraphColorHelp" class="form-text">The color to render this device's historical graph with under Logs &amp; Graphs</div>
    </div>
    <div>
      <label for="SwitchSec" class="form-label">AUTO/ON/OFF Switch Minimum Security Level</label>
      <?= SwitchSecSelector($Dev["SwitchSec"]) ?>
    </div>
    <div style="margin-top: 1em; margin-bottom: 1em;">
      <label for="OverrideID" class="form-label">Assigned Override Output Switch</label>
      <?= OutputSelector($Dev["OverrideID"],$_GET["DeviceID"],"OverrideID") ?>
      <label for="OverrideStatus" class="form-label">Override Switch Status <span class="text-muted"><i>(To Prevent Activation)</i></span></label>
      <?= OnOffSelector($Dev["OverrideStatus"],"OverrideStatus") ?>
    </div>
    <div id="HighLowDiv">
      <div class="row" style="width:99%;">
        <label for="BGlow" class="form-label">Switching Range for Variable Value Sensors</label>
        <div class="col"><input type="number" class="form-control" id="LowValue" name="LowValue" value="<?= $Dev["LowValue"]  ?>"></div>
        <div class="col"><input type="number" class="form-control" id="HighValue" name="HighValue" value="<?= $Dev["HighValue"]  ?>"></div>
      </div>
      <div class="row" style="width:99%; margin-bottom: 0.5em;">
        <div class="col text-muted">Low Value</div>
        <div class="col text-muted">High Value</div>
      </div>
    </div>
    <div id="PolarityDiv">
      <label for="Polarity" class="form-label">Switching Polarity for Variable Value Sensors</label>
      <?= PolaritySelector($Dev["Polarity"]) ?>
    </div>
    <div class="mb-3" style="margin-top: 1em;">
      <label for="OneShot" class="form-label">One-Shot ON/OFF Command Mode</label>
      <?= YNSelector($Dev["OneShot"],"OneShot") ?>
      <div id="OneShotHelp" class="form-text">Yes = run commands once per status change, No = run commands every minute</div>
    </div>
    <div style="margin-top: 1em; margin-bottom: 1em;">
      <label for="Notes" class="form-label">Device Notes</label>
      <textarea class="form-control" id="Notes" name="Notes" style="height: 100px;"><?= $Dev["Notes"] ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary" name="cz_output_switch_save">Submit</button>
    <input type="hidden" name="ID" value="<?= $_GET["DeviceID"] ?>">
    <input type="hidden" name="LOGGED_IN_KEY" value="<?= LOGGED_IN_KEY ?>">
    <input type="hidden" name="RETURN_PAGE" value="<?= $_GET["RETURN_PAGE"] . "?DevType=1" ?>">
    </form>
  </div>
<?php } ?>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
</body>
</html>
