<?php
//---------------------------------------------------------------------------------------------------
require_once("../../../wp-config.php");
require_once("subs.php");
//---------------------------------------------------------------------------------------------------
$CZ_WIDTH  = $_COOKIE["CZ_WIDTH"];
$CZ_HEIGHT = $_COOKIE["CZ_HEIGHT"];
//---------------------------------------------------------------------------------------------------
$StartTime = $_GET["StartTime"]; // Duh
$EndTime   = $_GET["EndTime"];   // Duh
$Input     = $_GET["Input"];     // 1=InputHistory, 0=OutputHistory
$ID        = $_GET["ID"];        // Duh
$Type      = $_GET["Type"];      // 1=Line, 2=Step
$Width     = $CZ_WIDTH - 100;    // Image width
$Height    = $_GET["Height"];    // Image height
$Labels    = $_GET["Labels"];    // 1=true, 0=false
$RGB       = explode(",",$_GET["RGB"]); // Duh
if ($Height < 210) $Labels = 0; // No room to plot the labels
if ($Labels == 0) { $Floor = $Height - 10; } else { $Floor = $Height - 100; }
$DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
//---------------------------------------------------------------------------------------------------
/*
   +- Example layout when $Labels=1
   |
   |                      28px top margin for label
   |         +-----------------------------------------------+
   |       - | Horizontal ticks                              |
   |       - | plot height / 4 or 8                          |
   |< 75px > |                  Graph Plot                   |
   |       - |                                               |
   |       - |                                               |
   |       - +-----------------------------------------------+
   |       ^  | | | | | | | | | | | | | | | | | | | | | | | |  < Vertical ticks and
   |       ^                                                     labels every 25px
   +- 100px^       if ($Height < 210) no room for labels
                   Bottom margin is 10px without labels

   # Tick marks outside of the graph plot are 5px in length
   # Chart.js is pretty but inefficient, it bogs down the user's browser
   # Sadly, PHP's graphics capabilities are nothing compared to FastGraph
   # This is cryptic and clumsy, but it caters better to weak mobile phones
*/
//---------------------------------------------------------------------------------------------------
$Image      = imagecreatetruecolor($Width,$Height);
$ImgBG      = imagecolorallocatealpha($Image,0,0,0,127);
$ImgGrid    = imagecolorallocate($Image,225,225,225);
$ImgLabel   = imagecolorallocate($Image,120,120,120);
$ImgLine    = imagecolorallocatealpha($Image,$RGB[0],$RGB[1],$RGB[2],75);
$PlotHeight = $Floor - 28;
$PlotWidth  = $Width - 75;
if ($Height < 300) {
  $GridYStep  = round_down($PlotHeight / 4,0);
  $GridYLines = 4;
} else {
  $GridYStep  = round_down($PlotHeight / 8,0);
  $GridYLines = 8;
}
// Fill entire image with a transparent background
imagealphablending($Image,false);
imagefill($Image,0,0,$ImgBG);
imagesavealpha($Image,true);
imagealphablending($Image,true);
//---------------------------------------------------------------------------------------------------
// Draw the grid
$YPos = $Floor;
for ($y = 0; $y <= $GridYLines; $y ++) {
  $HLabel[] = $YPos;
  imageline($Image,70,$YPos,$Width,$YPos,$ImgGrid);
  $YPos -= $GridYStep;
}
$XPos = 75;
while ($XPos <= $Width) {
  $VLabel[] = $XPos;
  imageline($Image,$XPos,$Floor + 5,$XPos,$Floor - $PlotHeight,$ImgGrid);
  $XPos += 25;
}
//---------------------------------------------------------------------------------------------------
// Load the data arrays
if ($Input == 1) {
  $Result = mysqli_query($DBcnx,"SELECT * FROM InputDevices WHERE ID=$ID");
  $RS     = mysqli_fetch_assoc($Result);
  $Title  = $RS["DeviceName"];
  $Result = mysqli_query($DBcnx,"SELECT * FROM InputHistory WHERE TimeStamp >= '$StartTime' AND TimeStamp <= '$EndTime' AND DeviceID=$ID ORDER BY ID");
} else {
  $Result = mysqli_query($DBcnx,"SELECT * FROM OutputSwitches WHERE ID=$ID");
  $RS     = mysqli_fetch_assoc($Result);
  $Title  = $RS["DeviceName"];
  $Result = mysqli_query($DBcnx,"SELECT * FROM OutputHistory WHERE TimeStamp >= '$StartTime' AND TimeStamp <= '$EndTime' AND DeviceID=$ID ORDER BY ID");
}
$MaxValue = 0;
if (mysqli_num_rows($Result) > 0) {
  while ($RS = mysqli_fetch_assoc($Result)) {
    if ($Input == 1) {
      if ($RS["Reading"] > $MaxValue) $MaxValue = $RS["Reading"];
      $Reading[] = $RS["Reading"];
    } else {
      $Reading[] = $RS["Status"];
    }
    $TimeStamp[] = substr($RS["TimeStamp"],11,8);
  }
}
$MaxValue = round_up($MaxValue,0);
// Plot the horizontal grid line labels
if ($Labels == 1) {
  if ($Type == 1) {
    $Value  = 0;
    $Factor = round_down($MaxValue / (count($HLabel) - 1),0);
    for ($y = 0; $y <= (count($HLabel) - 1); $y ++) {
      imagestring($Image,5,10,$HLabel[$y] - 8,str_pad($Value,6," ",STR_PAD_LEFT),$ImgLabel);
      $Value += $Factor;
    }
  } else {
    imagestring($Image,5,38,$HLabel[(count($HLabel) - 1)] - 8," ON",$ImgLabel);
    imagestring($Image,5,38,$HLabel[0] - 8,"OFF",$ImgLabel);
  }
}
//---------------------------------------------------------------------------------------------------
if (($Type == 1) && (isset($Reading))) { // Linear Line Chart
  $Records = count($Reading);
  $RecNum  = 0;
  $Column  = 75;
  $VDiv    = $PlotHeight / $MaxValue;
  if ($Records < $PlotWidth) {
    // Too few readings to fill the entire $PlotWidth
    // $RecordIndex[] contains the columns for readings
    $Factor = $PlotWidth / $Records;
    for ($x = 0; $x <= ($Records - 1); $x ++) {
      $RecordIndex[] = round_up($x * $Factor,0) + 75;
    }
  } else {
    // Delete random readings until $Records = $PlotWidth
    while ($Records > $PlotWidth) {
      $Index = rand(1,$Records - 2);
      unset($Reading[$Index]);
      unset($TimeStamp[$Index]);
      $Reading   = array_values($Reading);
      $TimeStamp = array_values($TimeStamp);
      $Records   = count($Reading);
    }
  }
  for ($x = 0; $x <= ($PlotWidth - 1); $x ++) {
    if ($Records < $PlotWidth) {
      // Stretch readings to fill the entire $PlotWidth
      $LineDone = false;
      for ($xx = 0; $xx <= ($Records - 1); $xx ++) {
        if ($Column == $RecordIndex[$xx]) {
          if (! $LineDone) {
            imageline($Image,$Column,$Floor,$Column,$Floor - ($Reading[$xx] * $VDiv),$ImgLine);
            $LineDone  = true;
            $LastValue = $Reading[$xx];
            $LastIndex = $xx;
            $Smoothing = 0;
          }
        }
      }
      if (! $LineDone) {
        if (isset($Reading[$LastIndex + 1])) {
          // Attempt to smooth peak transitions between readings
          if ($Smoothing == 0) {
            if ($Reading[$LastIndex + 1] > $LastValue) {
              $Smoothing = ($Reading[$LastIndex + 1] - $LastValue) / $Factor;
            } else {
              $Smoothing = ($LastValue - $Reading[$LastIndex + 1]) / $Factor;
            }
          }
          if ($Reading[$LastIndex + 1] > $LastValue) {
            $LastValue += $Smoothing;
          } else {
            $LastValue -= $Smoothing;
          }
        }
        imageline($Image,$Column,$Floor,$Column,$Floor - ($LastValue * $VDiv),$ImgLine);
      }
    } else {
      // No stretching, we have one $Reading[] record per $x loop value
      imageline($Image,$Column,$Floor,$Column,$Floor - ($Reading[$x] * $VDiv),$ImgLine);
    }
    // Plot a vertical/column label if $Column is equal to a vertical grid line
    if ($Labels == 1) {
      for ($xx = 0; $xx <= (count($VLabel) - 1); $xx ++) {
        if ($Column == $VLabel[$xx]) {
          if ($Records < $PlotWidth) {
            // Since we're stretching readings, we just plot the last available time stamp
            imagestringup($Image,4,$Column - 8,$Height - 16,$TimeStamp[$LastIndex] . " >",$ImgLabel);
          } else {
            // In this case, the time stamp indexes always follow the $x loop value
            imagestringup($Image,4,$Column - 8,$Height - 16,$TimeStamp[$x] . " >",$ImgLabel);
          }
        }
      }
    }
    $Column ++;
  }
}
//---------------------------------------------------------------------------------------------------
if (($Type == 2) && (isset($Reading))) { // Stepped Line Chart
  $Records = count($Reading);
  $RecNum  = 0;
  $Column  = 75;
  $VDiv    = $PlotHeight;
  if ($Records < $PlotWidth) {
    // Too few readings to fill the entire $PlotWidth
    // $RecordIndex[] contains the columns for readings
    $Factor = $PlotWidth / $Records;
    for ($x = 0; $x <= ($Records - 1); $x ++) {
      $RecordIndex[] = round_up($x * $Factor,0) + 75;
    }
  } else {
    // Delete reading zero until $Records = $PlotWidth
    while ($Records > $PlotWidth) {
      unset($Reading[0]);
      unset($TimeStamp[0]);
      $Reading   = array_values($Reading);
      $TimeStamp = array_values($TimeStamp);
      $Records   = count($Reading);
    }
  }
  $LabelToggle = true;
  for ($x = 0; $x <= ($PlotWidth - 1); $x ++) {
    if ($Records < $PlotWidth) {
      // Stretch readings to fill the entire $PlotWidth
      $LineDone = false;
      for ($xx = 0; $xx <= ($Records - 1); $xx ++) {
        if ($Column == $RecordIndex[$xx]) {
          if (! $LineDone) {
            imageline($Image,$Column,$Floor,$Column,$Floor - ($Reading[$xx] * $VDiv),$ImgLine);
            if ($Labels == 1) imagefilledellipse($Image,$Column,$Floor - ($Reading[$xx] * $VDiv),8,8,$ImgLine);
            $LabelToggle = true;
            $LineDone    = true;
            $LastValue   = $Reading[$xx];
            $LastIndex   = $xx;
          }
        }
      }
      // Attempt to smooth peak transitions between readings
      if (! $LineDone) {
        imageline($Image,$Column,$Floor,$Column,$Floor - ($LastValue * $VDiv),$ImgLine);
      }
    } else {
      // No stretching, we have one $Reading[] record per $x loop value
      imageline($Image,$Column,$Floor,$Column,$Floor - ($Reading[$x] * $VDiv),$ImgLine);
    }
    if ($Labels == 1) {
      for ($xx = 0; $xx <= (count($VLabel) - 1); $xx ++) {
        if ($Column == $VLabel[$xx]) {
          if ($Records < $PlotWidth) {
            // Since we're stretching readings, we just plot the last available time stamp
            if ($LabelToggle) {
              $Color = $ImgLabel;
            } else {
              $Color = $ImgLine;
            }
            imagestringup($Image,4,$Column - 8,$Height - 16,$TimeStamp[$LastIndex] . " >",$Color);
            $LabelToggle = false;
          } else {
            // In this case, the time stamp indexes always follow the $x loop value
            imagestringup($Image,4,$Column - 8,$Height - 16,$TimeStamp[$x] . " >",$ImgLabel);
          }
        }
      }
    }
    $Column ++;
  }
}
//---------------------------------------------------------------------------------------------------
mysqli_close($DBcnx);
if ((isset($_COOKIE["CZ_OV"])) && ($_COOKIE["CZ_OV"] == 1) && ($Height < 210)) $Image = imagescale($Image,$Width * 0.2,$Height,IMG_BICUBIC);
$ImageWidth = imagesx($Image);
$TitleWidth = strlen($Title) * 8;
$TitlePos   = ($ImageWidth / 2) - ($TitleWidth / 2);
imagestring($Image,5,$TitlePos,7,$Title,$ImgLabel);
header("Content-Type: image/png");
imagepng($Image);
imagedestroy($Image);
//---------------------------------------------------------------------------------------------------
?>
