<?php
/*
* Plugin Name: Climate Czar
* Plugin URI: https://github.com/larry-athey/climate-czar
* Description: Universal remote climate monitoring and management system for greenhouses and indoor grow operations.
* Author: Larry Athey - Panhandle Ponics
* Author URI: https://panhandleponics.com
* Version: 1.0.0
* Text Domain: remote-monitoring-and-management
* Domain Path: /languages/
* Network: ______________
* Requires at least: 3.0.0
* Requires PHP: 7.2
*/
require_once("functions.php");
//---------------------------------------------------------------------------------------------------
add_shortcode("cz_test","cz_test");
add_action("init","Process_Protect");
//---------------------------------------------------------------------------------------------------
add_shortcode("cz_list_devices","cz_list_devices");
add_shortcode("cz_list_groups","cz_list_groups");
add_shortcode("cz_list_scripts","cz_list_scripts");
add_shortcode("cz_logs_graphs","cz_logs_graphs");
add_shortcode("cz_menu_bar","cz_menu_bar");
add_shortcode("cz_show_all_sensors","cz_show_all_sensors");
add_shortcode("cz_show_all_switches","cz_show_all_switches");
add_shortcode("cz_show_sensor","cz_show_sensor");
add_shortcode("cz_show_switch","cz_show_switch");
//---------------------------------------------------------------------------------------------------
?>
