<?php
$TZ="America/Denver";
?>
