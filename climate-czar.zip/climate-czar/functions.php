<?php
//---------------------------------------------------------------------------------------------------
require_once("subs.php");
//---------------------------------------------------------------------------------------------------
if ($_GET) {
  if (isset($_GET["CZ_BASIC"])) {
    if ($_GET["CZ_BASIC"] == 1) {
      setcookie("CZ_BASIC",1,0,"/");
      define("CZ_BASIC",true);
    } else {
      setcookie("CZ_BASIC",0,0,"/");
      define("CZ_BASIC",false);
    }
  }
  if (isset($_GET["CZ_GROUP"])) {
    setcookie("CZ_GROUP",$_GET["CZ_GROUP"],0,"/");
    define("CZ_GROUP",$_GET["CZ_GROUP"]);
  }
}

if (! defined("CZ_BASIC")) {
  if (isset($_COOKIE["CZ_BASIC"])) {
    if ($_COOKIE["CZ_BASIC"] == 1) {
      define("CZ_BASIC",true);
    } else {
      define("CZ_BASIC",false);
    }
  } else {
    setcookie("CZ_BASIC",0,0,"/");
    define("CZ_BASIC",false);
  }
}

if (! defined("CZ_GROUP")) {
  if (isset($_COOKIE["CZ_GROUP"])) {
    define("CZ_GROUP",$_COOKIE["CZ_GROUP"]);
  } else {
    setcookie("CZ_GROUP",1,0,"/");
    define("CZ_GROUP",1);
  }
}
//---------------------------------------------------------------------------------------------------
function Process_Protect() {
  // Cheap but very effective trick to protect process.php from nefarious curl posts
  // Just try to avoid opening a form before midnight and submitting it after midnight
  $FN = basename($_SERVER["SCRIPT_FILENAME"]);
  if (($FN == "index.php") && (is_user_logged_in())) {
    $D = date('w');
    if ($D == 0) { setcookie("PrOcEsS012023",AUTH_KEY,time()+60*60,"/"); }
    elseif ($D == 1) { setcookie("PrOcEsS012023",SECURE_AUTH_KEY,time()+60*60,"/"); }
    elseif ($D == 2) { setcookie("PrOcEsS012023",NONCE_KEY,time()+60*60,"/"); }
    elseif ($D == 3) { setcookie("PrOcEsS012023",AUTH_SALT,time()+60*60,"/"); }
    elseif ($D == 4) { setcookie("PrOcEsS012023",SECURE_AUTH_SALT,time()+60*60,"/"); }
    elseif ($D == 5) { setcookie("PrOcEsS012023",LOGGED_IN_SALT,time()+60*60,"/"); }
    elseif ($D == 6) { setcookie("PrOcEsS012023",NONCE_SALT,time()+60*60,"/"); }
  }
}
//---------------------------------------------------------------------------------------------------
function cz_test() {
/*
*/
  if (is_user_logged_in()) {

  }
}
//---------------------------------------------------------------------------------------------------
function cz_list_devices() {
  $LOGGED_IN_KEY = urlencode(LOGGED_IN_KEY);
  $RETURN_PAGE   = urlencode(get_site_url() . "/list-devices/");
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $DevType = 0;
  $FormID  = 2;
  $BtnLbl  = "Input Sensor";
  if (isset($_GET["DevType"])) $DevType = $_GET["DevType"];
  if ($DevType == 1) {
    $FormID = 3;
    $BtnLbl  = "Output Switch";
  }
  $Content  = "<div class=\"card\" style=\"margin-bottom: 1em;\">";
  $Content .=   "<div class=\"card-body\">";
  $Content .=     "<table class=\"table table-borderless\">";
  $Content .=       "<tr>";
  $Content .=         "<td width=\"30%\">";
  $Content .=           DeviceListSelector($DBcnx,CZ_GROUP,$DevType);
  $Content .=           "<a class=\"btn btn-outline-secondary\" href=\"" . plugins_url() . "/climate-czar/formedit.php?FormID=$FormID&DeviceID=0&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\" target=\"formedit\" role=\"button\" style=\"width: 100%;margin-bottom: 0.5em;\">Add New $BtnLbl</a>";
  $Content .=           "<div style=\"height:73vh;width:100%;float:left;overflow-y:scroll;\">";
  $Content .=             "<table class=\"table table-striped table-hover\">";
  if ($DevType == 0) {
    $Result = mysqli_query($DBcnx,"SELECT * FROM InputDevices WHERE GroupID=" . CZ_GROUP ." ORDER BY DeviceName");
  } else {
    $Result = mysqli_query($DBcnx,"SELECT * FROM OutputSwitches WHERE GroupID=" . CZ_GROUP ." ORDER BY DeviceName");
  }
  if (mysqli_num_rows($Result) > 0) {
    while ($Dev = mysqli_fetch_assoc($Result)) {
      $Content .= "<tr><td class=\"align-middle\">" . $Dev["DeviceName"] . "</td>";
      $Content .= "<td nowrap align=\"right\"><a class=\"btn btn-success btn-sm\" href=\"" . plugins_url() . "/climate-czar/formedit.php?FormID=$FormID&DeviceID=" . $Dev["ID"] . "&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\" target=\"formedit\" role=\"button\">Edit</a>" .
                  "&nbsp;&nbsp;<a onClick=\"ConfirmDeviceDelete('$LOGGED_IN_KEY','$RETURN_PAGE','$DevType','" . $Dev["ID"] . "','" . $Dev["DeviceName"] . "')\" class=\"btn btn-danger btn-sm\" role=\"button\">Delete</a>" .
                  "</td></tr>";
    }
  }
  $Content .=             "</table>";
  $Content .=           "</div>";
  $Content .=         "</td>";
  $Content .=         "<td width=\"70%\">";
  $Content .=           "<iframe type=\"text/html\" name=\"formedit\" style=\"height:82vh;width:50%;float:left;overflow-y:auto;border:none;\" src=\"" . plugins_url() . "/climate-czar/formedit.php?FormID=0&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\"\">";
  $Content .=         "</td>";
  $Content .=       "</tr>";
  $Content .=     "</table>";
  $Content .=   "</div>";
  $Content .= "</div>";
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_list_groups() {
  $LOGGED_IN_KEY = urlencode(LOGGED_IN_KEY);
  $RETURN_PAGE   = urlencode(get_site_url() . "/list-groups/");
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Content  = "<div class=\"card\" style=\"margin-bottom: 1em;\">";
  $Content .=   "<div class=\"card-body\">";
  $Content .=     "<table class=\"table table-borderless\">";
  $Content .=       "<tr>";
  $Content .=         "<td width=\"30%\">";
  $Content .=           "<a class=\"btn btn-outline-secondary\" href=\"" . plugins_url() . "/climate-czar/formedit.php?FormID=1&GroupID=0&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\" target=\"formedit\" role=\"button\" style=\"width: 100%;margin-bottom: 0.5em;\">Create New Group</a>";
  $Content .=           "<div style=\"height:77.5vh;width:100%;float:left;overflow-y:scroll;\">";
  $Content .=             "<table class=\"table table-striped table-hover\">";
  $Result = mysqli_query($DBcnx,"SELECT * FROM DeviceGroups ORDER BY Name");
  while ($Group = mysqli_fetch_assoc($Result)) {
    $Content .=           "<tr><td class=\"align-middle\">" . $Group["Name"] . "</td>" .
                          "<td align=\"right\"><a class=\"btn btn-success btn-sm\" href=\"" . plugins_url() . "/climate-czar/formedit.php?FormID=1&GroupID=" . $Group["ID"] . "&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\" target=\"formedit\" role=\"button\">Edit</a>";
    if ($Group["ID"] > 1) {
      $Content .=         "&nbsp;&nbsp;<a onClick=\"ConfirmGroupDelete('$LOGGED_IN_KEY','$RETURN_PAGE','" . $Group["ID"] . "','" . $Group["Name"] . "')\" class=\"btn btn-danger btn-sm\" role=\"button\">Delete</a>";
    }
    $Content .=           "</td></tr>";
  }
  $Content .=             "</table>";
  $Content .=           "</div>";
  $Content .=         "</td>";
  $Content .=         "<td width=\"70%\">";
  $Content .=           "<iframe type=\"text/html\" name=\"formedit\" style=\"height:82vh;width:50%;float:left;overflow-y:auto;border:none;\" src=\"" . plugins_url() . "/climate-czar/formedit.php?FormID=0&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\">";
  $Content .=         "</td>";
  $Content .=       "</tr>";
  $Content .=     "</table>";
  $Content .=   "</div>";
  $Content .= "</div>";
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_list_scripts() {
  $LOGGED_IN_KEY = urlencode(LOGGED_IN_KEY);
  $RETURN_PAGE   = urlencode(get_site_url() . "/list-scripts/");
  $Files = array_diff(scandir(ABSPATH . "commands/"),array('.','..'));
  $Files = array_values($Files);
  $Query = "?LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE";
  if (isset($_GET["ScriptName"])) $Query .= "&ScriptName=" . $_GET["ScriptName"];
  $Content  = "<div class=\"card\" style=\"margin-bottom: 1em;\">";
  $Content .=   "<div class=\"card-body\">";
  $Content .=     "<table class=\"table table-borderless\">";
  $Content .=       "<tr>";
  $Content .=         "<td width=\"30%\">";
  $Content .=           "<div style=\"height:80vh;width:100%;float:left;overflow-y:scroll;\">";
  $Content .=             "<table class=\"table table-striped table-hover\">";
  for ($x = 0; $x <= (count($Files) - 1); $x ++) {
    $Pos = strpos($Files[$x],"cz-",0);
    if ($Pos !== false) { /* File Name starts with "cz-" */ } else {
      $Content .=           "<tr><td class=\"align-middle\">$Files[$x]</td>" .
                            "<td align=\"right\"><a class=\"btn btn-success btn-sm\" href=\"" . plugins_url() . "/climate-czar/scriptedit.php?ScriptName=$Files[$x]&LOGGED_IN_KEY=$LOGGED_IN_KEY&RETURN_PAGE=$RETURN_PAGE\" target=\"vscode\" role=\"button\">Edit</a>" .
                            "&nbsp;&nbsp;<a onClick=\"ConfirmScriptDelete('$LOGGED_IN_KEY','$RETURN_PAGE','$Files[$x]')\" class=\"btn btn-danger btn-sm\" role=\"button\">Delete</a></td></tr>";
    }
  }
  $Content .=             "</table>";
  $Content .=           "</div>";
  $Content .=         "</td>";
  $Content .=         "<td width=\"70%\">";
  $Content .=           "<iframe type=\"text/html\" name=\"vscode\" style=\"height:82vh;width:100%;float:left;overflow-y:auto;border:none;\" src=\"" . plugins_url() . "/climate-czar/scriptedit.php$Query\">";
  $Content .=         "</td>";
  $Content .=       "</tr>";
  $Content .=     "</table>";
  $Content .=   "</div>";
  $Content .= "</div>";
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_logs_graphs() {
  $DBcnx    = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Now      = time();
  $Now_6    = ($Now - 21600);
  $TStart   = str_replace(" ","T",date('Y-m-d H:i',$Now_6));
  $TEnd     = str_replace(" ","T",date('Y-m-d H:i',$Now));
  if (CZ_BASIC) {
    $CZ_BASIC = 1;
  } else {
    $CZ_BASIC = 0;
  }
  $Content  = "<div class=\"card\" style=\"margin-bottom: 1em;\">";
  $Content .=   "<div class=\"card-body\">";
  $Content .=     "<form method=\"post\" action=\"" . plugins_url() . "/climate-czar/charts.php\" target=\"charts\">";
  $Content .=     "<input type=\"hidden\" name=\"CZ_BASIC\" value=\"" . CZ_BASIC . "\">";
  $Content .=     "<input type=\"hidden\" name=\"CZ_GROUP\" value=\"" . CZ_GROUP . "\">";
  $Content .=     "<div class=\"container text-center\" style=\"margin-bottom: 1em;\">";
  $Content .=       "<div class=\"row\">";
  $Content .=         "<div class=\"col-2\"><input class=\"form-control\" type=\"datetime-local\" id=\"StartTime\" name=\"StartTime\" value=\"$TStart\"></div>";
  $Content .=         "<div class=\"col-2\"><input class=\"form-control\" type=\"datetime-local\" id=\"EndTime\" name=\"EndTime\" value=\"$TEnd\"></div>";
  $Content .=         "<div class=\"col-3\">" . ChartsDeviceSelector($DBcnx,CZ_GROUP) . "</div>";
  $Content .=         "<div class=\"col-3\" style=\"text-align: right;\"><button type=\"submit\" class=\"btn btn-success\" name=\"cz_show_graphs\">Show Charts &amp; Graphs</button></div>";
  $Content .=         "<div class=\"col-2\" style=\"text-align: left;\"><button type=\"submit\" class=\"btn btn-success\" name=\"cz_show_logs\">Show Device Log</button></div>";
  $Content .=       "</div>";
  $Content .=     "</div>";
  $Content .=     "</form>";
  $Content .=     "<iframe type=\"text/html\" name=\"charts\" style=\"height:78vh;width:100%;float:left;overflow-y:auto;border:none;\" src=\"" . plugins_url() . "/climate-czar/charts.php?CZ_BASIC=$CZ_BASIC&CZ_GROUP=" . CZ_GROUP . "\">";
  $Content .=   "</div>";
  $Content .= "</div>";
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_menu_bar() {
  $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Content  = "<nav class=\"navbar navbar-expand-lg\" style=\"background-color: #7fca90;\">";
  $Content .=   "<div class=\"container-fluid\">";
  $Content .=     "<a class=\"navbar-brand\" href=\"" . get_site_url() . "/\"><span class=\"iconify text-white\" style=\"font-size: 1.5em;\" data-icon=\"game-icons:greenhouse\"></span>&nbsp;<span class=\"text-white\" style=\"font-weight: bold;\">Climate Czar</span></a>";
  $Content .=     "<button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">";
  $Content .=       "<span class=\"navbar-toggler-icon\"></span>";
  $Content .=     "</button>";
  $Content .=     "<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">";
  $Content .=       "<ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">";
  $Content .=         "<li class=\"nav-item\">";
  $Content .=           "<a class=\"nav-link\" aria-current=\"page\" href=\"" . get_site_url() . "/\">Home</a>";
  $Content .=         "</li>";
  $Content .=         "<li class=\"nav-item\">";
  $Content .=           "<a class=\"nav-link\" href=\"" . get_site_url() . "/logs-graphs/\">Logs & Graphs</a>";
  $Content .=         "</li>";
  $Content .=         "<li class=\"nav-item dropdown\">";
  $Content .=           "<a class=\"nav-link dropdown-toggle\" href=\"#\" role=\"button\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">Change Group</a>";
  $Content .=           "<ul class=\"dropdown-menu\" style=\"background-color: #abeeba;\">";
  $Result = mysqli_query($DBcnx,"SELECT * FROM DeviceGroups ORDER BY Name");
  while ($Group = mysqli_fetch_assoc($Result)) {
    if ($Group["ID"] == CZ_GROUP) $GroupName =$Group["Name"];
    $Group["Name"] = str_replace(" ","&nbsp;",$Group["Name"]);
    $Content .=           "<li><a class=\"dropdown-item\" href=\"" . $_SERVER["PHP_SELF"] . "?CZ_GROUP=" . $Group["ID"] . "\">" . $Group["Name"] . "</a></li>";
  }
  $Content .=           "</ul>";
  $Content .=         "</li>";
  $Content .=         "<li class=\"nav-item dropdown\">";
  $Content .=           "<a class=\"nav-link dropdown-toggle\" href=\"#\" role=\"button\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">Management</a>";
  $Content .=           "<ul class=\"dropdown-menu\" style=\"background-color: #abeeba;\">";
  $Content .=             "<li><a class=\"dropdown-item\" href=\"" . get_site_url() . "/list-devices/\">Manage&nbsp;Devices</a></li>";
  $Content .=             "<li><a class=\"dropdown-item\" href=\"" . get_site_url() . "/list-scripts/\">Manage&nbsp;Scripts</a></li>";
  $Content .=             "<li><a class=\"dropdown-item\" href=\"" . get_site_url() . "/list-groups/\">Manage&nbsp;Groups</a></li>";
  $Content .=             "<li><hr class=\"dropdown-divider\"></li>";
  $Content .=             "<li><a class=\"dropdown-item\" href=\"" . $_SERVER["PHP_SELF"] . "?CZ_BASIC=0\">Set&nbsp;Desktop&nbsp;View</a></li>";
  $Content .=             "<li><a class=\"dropdown-item\" href=\"" . $_SERVER["PHP_SELF"] . "?CZ_BASIC=1\">Set&nbsp;Basic&nbsp;Mobile&nbsp;View</a></li>";
  $Content .=           "</ul>";
  $Content .=         "</li>";
  $Content .=         "<li class=\"nav-item\">";
  $Content .=           "<a class=\"nav-link disabled\">Current Group: $GroupName</a>";
  $Content .=         "</li>";
  $Content .=       "</ul>";
  $Content .=     "</div>";
  $Content .=   "</div>";
  $Content .= "</nav>";
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_show_all_sensors() {
  $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Result = mysqli_query($DBcnx,"SELECT * FROM InputDevices WHERE Dashboard=1 AND GroupID=" . CZ_GROUP . " ORDER BY Position");
  if (CZ_BASIC) {
    $Content = "";
  } else {
    $Content  = "<div class=\"container-fluid\">";
    $Content .=   "<div class=\"row\">";
  }
  if (mysqli_num_rows($Result) > 0) {
    while ($Sensor = mysqli_fetch_assoc($Result)) {
      $Data["id"] = $Sensor["ID"];
      if (CZ_BASIC) {
        $Content .= cz_show_sensor($Data);
      } else {
        $Content .= "<div class=\"col\">";
        $Content .= cz_show_sensor($Data);
        $Content .= "</div>";
      }
    }
  }
  if (CZ_BASIC) {

  } else {
    $Content .=   "</div>";
    $Content .= "</div>";
  }
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_show_all_switches() {
  $DBcnx  = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Result = mysqli_query($DBcnx,"SELECT * FROM OutputSwitches WHERE Dashboard=1 AND GroupID=" . CZ_GROUP . " ORDER BY Position");
  if (CZ_BASIC) {
    $Content = "";
  } else {
    $Content  = "<div class=\"container-fluid\">";
    $Content .=   "<div class=\"row\">";
  }
  if (mysqli_num_rows($Result) > 0) {
    while ($Switch = mysqli_fetch_assoc($Result)) {
      $Data["id"] = $Switch["ID"];
      if (CZ_BASIC) {
        $Content .= cz_show_switch($Data);
      } else {
        $Content .= "<div class=\"col\">";
        $Content .= cz_show_switch($Data);
        $Content .= "</div>";
      }
    }
  }
  if (CZ_BASIC) {

  } else {
    $Content .=   "</div>";
    $Content .= "</div>";
  }
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_show_sensor($Data) {
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  if (isset($Data["id"])) {
    $Result = mysqli_query($DBcnx,"SELECT * FROM InputDevices WHERE ID=" . $Data["id"]);
    if (mysqli_num_rows($Result) > 0) {
      $Sensor = mysqli_fetch_assoc($Result);
      if (! isset($Data["noajax"])) {
        $RandID   = "input_" . generateRandomString();
        $Content  = AjaxRefreshJS($Sensor["ID"],$RandID,"input");
        $Content .= "<div id=\"$RandID\">";
      } else {
        $Content = "";
      }
      if (CZ_BASIC) {
        $Content .= "<table class=\"table table-success table-striped\" style=\"margin-bottom: .5em;\">";
        $Content .= "<tr><td><span style=\"font-weight: bold;\">" . $Sensor["DeviceName"] . "</span></td></tr>";
        if ($Sensor["DeviceType"] <= 2) {
          $Content .= "<tr><td align=\"right\">Current Reading: " . RenderValueBasic($Sensor["Reading"],$Sensor["BGlow"],$Sensor["BGmid"],$Sensor["BGhigh"],$Sensor["ReadingSuffix"]) . "</td></tr>";
        } elseif ($Sensor["DeviceType"] <= 7) {
          $Content .= "<tr><td align=\"right\">Current Status: " . RenderBinary($Sensor["Reading"],true) . "</td></tr>";
        } elseif ($Sensor["DeviceType"] == 8) {
          if (UserSec() >= DeviceSec($Sensor["SwitchSec"])) {
            $Content .= "<tr><td>" . InputSwitchControls(1,$Sensor["ID"],$Sensor["Reading"],"Current&nbsp;Status:&nbsp;" . RenderBinary($Sensor["Reading"],true)) . "</td></tr>";
          } else {
            $Content .= "<tr><td>" . DisabledInputSwitchControls(1,$Sensor["ID"],$Sensor["Reading"],"Current&nbsp;Status:&nbsp;" . RenderBinary($Sensor["Reading"],true)) . "</td></tr>";
          }
        } elseif ($Sensor["DeviceType"] == 9) {
          $Content .=   "<tr><td><div style=\"height:10.3vh;width:100%;float:left;overflow-y:scroll;\">" . $Sensor["RawText"] . "</div></td></tr>";
        }
        $Content .= "</table>";
      } else {
        $Content .=   "<div class=\"card\" style=\"width: 28rem; margin-bottom: 1em; margin-left: -1em; margin-right: 0.5em;\">";
        $Content .=     "<div class=\"card-body\">";
        $Content .=       "<p style=\"font-weight: bold;\">" . $Sensor["DeviceName"] . "</p>";
        if ($Sensor["DeviceType"] <= 2) {
          $Content .=     RenderValue($Sensor["Reading"],$Sensor["BGlow"],$Sensor["BGmid"],$Sensor["BGhigh"],$Sensor["ReadingSuffix"]);
          $Content .=     RenderProgressBar($Sensor["Reading"],$Sensor["BGlow"],$Sensor["BGmid"],$Sensor["BGhigh"]);
        } elseif ($Sensor["DeviceType"] <= 7) {
          if ($Sensor["DeviceType"] == 3) {
            $Label = "Remote Binary Switch";
          } elseif ($Sensor["DeviceType"] == 4) {
            $Label = "Logical AND Gate";
          } elseif ($Sensor["DeviceType"] == 5) {
            $Label = "Logical OR Gate";
          } elseif ($Sensor["DeviceType"] == 6) {
            $Label = "Logical NOT Gate";
          } elseif ($Sensor["DeviceType"] == 7) {
            $Label = "Daily Scheduler";
          }
          $Content .=     RenderBinary($Sensor["Reading"],false);
          $Content .=     "<p class=\"text-muted\" style=\"font-weight: bold;float: right;\">Sensor Type: <span class=\"text-primary-emphasis\">$Label</span></p>";
        } elseif ($Sensor["DeviceType"] == 8) {
          $Content .=     RenderBinary($Sensor["Reading"],false);
          if (UserSec() >= DeviceSec($Sensor["SwitchSec"])) {
            $Content .=   InputSwitchControls(0,$Sensor["ID"],$Sensor["Reading"],"");
          } else {
            $Content .=   DisabledInputSwitchControls(0,$Sensor["ID"],$Sensor["Reading"],"");
          }
        } elseif ($Sensor["DeviceType"] == 9) {
          $Content .=     "<div style=\"height:10.5vh;width:100%;float:left;overflow-y:scroll;\">";
          $Content .=     $Sensor["RawText"];
          $Content .=     "</div>";
        }
        $Content .=     "</div>";
        $Content .=   "</div>";
      }
      if (! isset($Data["noajax"])) {
        $Content .= "</div>";
      }
    }
  }
  mysqli_close($DBcnx);
  return $Content;
}
//---------------------------------------------------------------------------------------------------
function cz_show_switch($Data) {
  $LOGGED_IN_KEY = urlencode(LOGGED_IN_KEY);
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  if (isset($Data["id"])) {
    $Result = mysqli_query($DBcnx,"SELECT * FROM OutputSwitches WHERE ID=" . $Data["id"]);
    if (mysqli_num_rows($Result) > 0) {
      $Switch = mysqli_fetch_assoc($Result);
      if (! isset($Data["noajax"])) {
        $RandID   = "output_" . generateRandomString();
        $Content  = AjaxRefreshJS($Switch["ID"],$RandID,"output");
        $Content .= "<div id=\"$RandID\">";
      } else {
        $Content = "";
      }
      if (CZ_BASIC) {
        $Content .= "<table class=\"table table-success table-striped\" style=\"margin-bottom: .5em;\">";
        $Content .= "<tr><td><span style=\"font-weight: bold;\">" . $Switch["DeviceName"] . "</span></td></tr>";
        if (UserSec() >= DeviceSec($Switch["SwitchSec"])) {
          $Content .= "<tr><td>" . OutputSwitchControls(1,$Switch["ID"],$Switch["OpMode"],"Current&nbsp;Status:&nbsp;" . FormatStatus($Switch["Status"])) . "</td></tr>";
        } else {
          $Content .= "<tr><td>" . DisabledOutputSwitchControls(1,$Switch["ID"],$Switch["OpMode"],"Current&nbsp;Status:&nbsp;" . FormatStatus($Switch["Status"])) . "</td></tr>";
        }
        $Content .= "</table>";
      } else {
        if ($Switch["InputType"] <= 2) {
          $LeftLabel1 = "Switch Polarity";
          $LeftValue1 = FormatPolarity($Switch["Polarity"]);
          $LeftLabel2 = "High Value";
          $LeftValue2 = FormatRange($Switch["HighValue"]);
          $LeftLabel3 = "Low Value";
          $LeftValue3 = FormatRange($Switch["LowValue"]);
        } else {
          $LeftLabel1 = "Sensor Type";
          $LeftValue1 = FormatRange("Binary Value");
          $LeftLabel2 = "Input Type";
          $LeftLabel3 = "Current State";
          $LeftValue3 = FormatBinarySensor($DBcnx,$Switch["InputID"]);
          if ($Switch["InputType"] == 3) {
            $LeftValue2 = FormatRange("Toggle");
          } elseif ($Switch["InputType"] == 4) {
            $LeftValue2 = FormatRange("AND Gate");
          } elseif ($Switch["InputType"] == 5) {
            $LeftValue2 = FormatRange("OR Gate");
          } elseif ($Switch["InputType"] == 6) {
            $LeftValue2 = FormatRange("NOT Gate");
          } elseif ($Switch["InputType"] == 7) {
            $LeftValue2 = FormatRange("Scheduler");
          } elseif ($Switch["InputType"] == 8) {
            $LeftValue2 = FormatRange("Web Console");
          }
        }
        $Content .=   "<div class=\"card\" style=\"width: 28rem; margin-bottom: 1em; margin-left: -1em; margin-right: 0.5em;\">";
        $Content .=     "<div class=\"card-body\">";
        $Content .=       "<p style=\"font-weight: bold;\">" . $Switch["DeviceName"] . "</p>";
        $Content .=       "<table class=\"table table-borderless table-sm\">";
        $Content .=          "<tr><td width=\"50%\"><span class=\"text-muted\">$LeftLabel1: </span>$LeftValue1</td><td width=\"50%\"><span class=\"text-muted\">Input Sensor: </span>" . FormatSensor($DBcnx,$Switch["InputID"]) . "</td></tr>";
        $Content .=          "<tr><td><span class=\"text-muted\">$LeftLabel2: </span>$LeftValue2</td><td><span class=\"text-muted\">Switch Mode: </span>" . FormatMode($Switch["OpMode"]) . "</td></tr>";
        $Content .=          "<tr><td><span class=\"text-muted\">$LeftLabel3: </span>$LeftValue3</td><td><span class=\"text-muted\">Switch Mode: </span>" . FormatStatus($Switch["Status"]) . "</td></tr>";
        if (UserSec() >= DeviceSec($Switch["SwitchSec"])) {
          $Content .=        "<tr><td colspan=\"2\">" . OutputSwitchControls(0,$Switch["ID"],$Switch["OpMode"],"") . "</td></tr>";
        } else {
          $Content .=        "<tr><td colspan=\"2\">" . DisabledOutputSwitchControls(0,$Switch["ID"],$Switch["OpMode"],"") . "</td></tr>";
        }
        $Content .=       "</table>";
        $Content .=     "</div>";
        $Content .=   "</div>";
      }
      if (! isset($Data["noajax"])) {
        $Content .= "</div>";
      }
    }
  }
  mysqli_close($DBcnx);
  return $Content;
}
 //---------------------------------------------------------------------------------------------------
?>
