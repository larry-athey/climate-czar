#!/usr/bin/php
<?php
  // If a person is using my Raspberry PI pellet stove controller, they must have a
  // variable value input sensor to monitor the OpMode value. If it is >= 3, there
  // needs to be a script that runs to forcefully keep the web console stove power
  // switch turned off until shutdown has completed. The assigned output switch that
  // runs this as its "Device On Command" must have "One Shot" turned off so it is
  // executed once per minute in order to keep the web console switch turned off.

  require_once("../wp-config.php");
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  $Result = mysqli_query($DBcnx,"UPDATE InputDevices SET Reading=0 WHERE ID=27");
  // ID number shown above the Device Name field in the device editor form -^^                 **
  $Result = mysqli_query($DBcnx,"INSERT INTO InputHistory (DeviceID,TimeStamp,Reading) VALUES (27,now(),0)");
  mysqli_close($DBcnx);
?>
