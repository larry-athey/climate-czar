#!/usr/bin/php
<?php
  // When dealing with kerosene heaters, you have to remember that the fuel gets thicker as
  // it gets colder and this can easily cause startup failures. Since Climate Czar executes
  // on/off commands and doesn't wait around to read back any output from those commands, we
  // need a special script that starts up the heater and waits around to see the temperature
  // start to rise to make sure the heater ignited. If it fails, we need to shut down power
  // to the heater and start it up again. This is usually all that's needed to get the fuel
  // flowing again. Once we see the temperature rise by a few degrees, this script can exit.

  require_once("../wp-config.php");
  $DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
  set_time_limit(1020); // Give this script a maximum lifespan of 17 minutes
  $OnCommand   = "/var/www/html/climateczar/commands/hs103 10.20.30.111 9999 on &";
  $OffCommand  = "/var/www/html/climateczar/commands/hs103 10.20.30.111 9999 off &";
  $TempDevice  = 3; // ID number of the temperature sensor to monitor
  $ThisDevice  = 2; // ID number of the output switch that controls this heater
  $LoopCounter = 0; // Used for time keeping rather than getting the system time
  $Attempts    = 0; // Make 4 attempts and then return control back to Climate Czar

  $Result = mysqli_query($DBcnx,"SELECT Reading FROM InputDevices WHERE ID=$TempDevice");
  $RS = mysqli_fetch_assoc($Result);
  $StartTemp = $RS["Reading"];
  echo(date("Y-m-d h:i:s") . " - Executing blast heater ON command at $StartTemp degrees\n");
  shell_exec($OnCommand);

  while ($Attempts <= 4) {
    $LoopCounter ++;
    sleep(1);
    $Result = mysqli_query($DBcnx,"SELECT Reading FROM InputDevices WHERE ID=$TempDevice");
    $RS = mysqli_fetch_assoc($Result);
    $NowTemp = $RS["Reading"];
    $TempDiff = $NowTemp - $StartTemp;
    if ($TempDiff >= 2) { // We have a 2 degree temperature rise, heater ignited successfully
      echo(date("Y-m-d h:i:s") . " - 2 degree rise detected at $NowTemp, returning control back to Climate Czar\n");
      mysqli_close($DBcnx);
      exit;
    }
    if (($LoopCounter == 240) && ($NowTemp <= $StartTemp)) { // 4 minutes and no temperature rise, restart the heater
      echo(date("Y-m-d h:i:s") . " - Ignition failure detected at $NowTemp degrees, restarting blast heater\n");
      shell_exec($OffCommand);
      sleep(15);
      shell_exec($OnCommand);
      $LoopCounter = 0;
      $Attempts ++;
      echo(date("Y-m-d h:i:s") . " - Attempt $Attempts of 4 completed\n");
    }
    if ($Attempts == 4) { // We've stopped and restarted 4 times, bail out now and let Climate Czar try again
      echo(date("Y-m-d h:i:s") . " - 4 attempts to restart the blast heater, returning control back to Climate Czar\n");
      sleep(15);
      shell_exec($OffCommand);
      $Result = mysqli_query($DBcnx,"UPDATE OutputSwitches SET Status=0,LastUpdate=now() WHERE ID=$ThisDevice");
      mysqli_close($DBcnx);
      exit;
    }
    // Check for a manual OFF while this loop is running and exit the script if necessary
    $Result = mysqli_query($DBcnx,"SELECT Status FROM OutputSwitches WHERE ID=$ThisDevice");
    $RS = mysqli_fetch_assoc($Result);
    if ($RS["Status"] == 0) {
      shell_exec($OffCommand);
      mysqli_close($DBcnx);
      exit;
    }
  }
?>
