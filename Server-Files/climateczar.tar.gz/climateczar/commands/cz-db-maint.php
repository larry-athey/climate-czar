#!/usr/bin/php
<?php
require_once("../wp-config.php");
require_once("../wp-content/plugins/climate-czar/subs.php");
//---------------------------------------------------------------------------------------------
$DBcnx = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,"ClimateCzar");
//---------------------------------------------------------------------------------------------
$Result = mysqli_query($DBcnx,"DELETE FROM InputHistory WHERE TimeStamp < (NOW() - INTERVAL 14 DAY)");
$Result = mysqli_query($DBcnx,"DELETE FROM OutputHistory WHERE TimeStamp < (NOW() - INTERVAL 14 DAY)");

$Result = mysqli_query($DBcnx,"OPTIMIZE TABLE DeviceGroups");
$Result = mysqli_query($DBcnx,"OPTIMIZE TABLE InputDevices");
$Result = mysqli_query($DBcnx,"OPTIMIZE TABLE InputHistory");
$Result = mysqli_query($DBcnx,"OPTIMIZE TABLE OutputSwitches");
$Result = mysqli_query($DBcnx,"OPTIMIZE TABLE OutputHistory");
//---------------------------------------------------------------------------------------------
mysqli_close($DBcnx);
//---------------------------------------------------------------------------------------------
?>
