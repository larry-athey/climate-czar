<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'Wordpress' );

/** Database username */
define( 'DB_USER', 'czdbuser' );

/** Database password */
define( 'DB_PASSWORD', 'Cl!m@t3cZ4r' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '#o[W6Y8eOhA/ik0iu+L4&rU{8 iPGp<f8[p5yPW#P8:/u2;;+2vKdqFKE>m(Wa+O' );
define( 'SECURE_AUTH_KEY',  'du<1E)/{4;NA~YI[KJ61#je&*Gvi9+F.d6vWFdr]_B4&>J!QcRF_P;}@.$-{sm]l' );
define( 'LOGGED_IN_KEY',    'V7649#U*J}u|/L=/pW8)K$bJBj(s#&4Y4|6X4^K/CN+xdlD%5t7hPRI1F!+O?{:;' );
define( 'NONCE_KEY',        'TVj@3*>8hSXU T}9_|kX,(XZ?&gcJR>&pB1j<4tLe*JU&LAL?aLMS}wB@.{2&Hf]' );
define( 'AUTH_SALT',        'Z[3ITh&&hbBBU%bn,PJ=hil(fF`N_D&,uyaNPKH@yZ`I6+heD~#3J-WQ-G8Y}}>N' );
define( 'SECURE_AUTH_SALT', '_4Jm$(T$L]K[;9X#*i7$GAS-iMMrAeS|4``8r)AbO=-0-53Sm]5R%!y>3clM0HxX' );
define( 'LOGGED_IN_SALT',   '3o~M6>;6?G?}I>d4j3SJ)7AuNM:<gFrk)ReD<O3RlFMD1ENDiLO`2$lAJuTQ8;Ej' );
define( 'NONCE_SALT',       'H?)G#`vsRi>l?qm3}Qd:6hd9aN6~87EM@tE;BiOTAxWj>9R+9V4;DM8|E(rE7u8]' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
